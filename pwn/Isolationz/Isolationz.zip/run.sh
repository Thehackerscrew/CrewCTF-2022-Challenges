#!/bin/sh
cd /home/ctf
LD_PRELOAD=/home/ctf/libc.so.6 /home/ctf/chall
