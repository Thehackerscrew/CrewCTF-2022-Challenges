import sqlite3,warnings
from sqlite3 import OperationalError
from telegram.ext import Updater, CommandHandler,CallbackContext

items = [] # for less querying
desclist = [] # for more querying

def intidb():
	global con
	con = sqlite3.connect('database.db')
	cur = con.cursor()
	data = cur.execute('SELECT id,name FROM items ORDER BY id')
	for row in data:
		data = str(row[0]) + " - " + row[1]
		items.append(data)

	datadesc = cur.execute('SELECT description FROM items ORDER BY id')
	for descrow in datadesc:
		datadesc = descrow[0]
		desclist.append(datadesc)



def funchelp(update, context):
	    update.message.reply_text(
        "/items - Return the item list.\n"
		"/price - Return the price of item.\n"
		"/desc - Return the description of item.\n"
		"/value - Return the value of item.\n"
        "/help or /start - list available commands to use.\n"
        "Use the command and specifiy the item ID")
	    print('Got start message from: '+str(update.message.from_user.username))

def funcitems(update, context):
	    update.message.reply_text('\n'.join(items))

def funcprice(update, context):
	con = sqlite3.connect('database.db')
	cur = con.cursor()
	price = cur.execute('''SELECT price FROM items WHERE id = ?''', (context.args[0])).fetchone()
	update.message.reply_text(price[0])
	con.close()

def funcdesc(update, context):
	con = sqlite3.connect('database.db')
	cur = con.cursor()
	try:
		desc = cur.execute("SELECT description FROM items WHERE id = '%s'" % str(''.join(context.args))).fetchone()
		if str(*desc,) in desclist:
				update.message.reply_text(*desc)
		else:
				update.message.reply_text('Old item from my grandfather age')
	except OperationalError:
			update.message.reply_text('Error has been occured')
	except TypeError:
			update.message.reply_text('Item not found')

	con.close()


def funcvalue(update, context):
	update.message.reply_text('This feature currently Temporary Disabled')


def main():
	warnings.filterwarnings('ignore')
	updater = Updater("") #Update telegram bot token
	dp = updater.dispatcher
	dp.add_handler(CommandHandler("start", funchelp))
	dp.add_handler(CommandHandler("help", funchelp))
	dp.add_handler(CommandHandler("items", funcitems))
	dp.add_handler(CommandHandler("price", funcprice))
	dp.add_handler(CommandHandler("desc", funcdesc))
	dp.add_handler(CommandHandler("value", funcvalue)) # Temporary Disabled
	intidb()
	print('[+] Robabikia bot is up at @crewctf_Robabikia_bot')
	updater.start_polling()
	updater.idle()

if __name__ == "__main__":
	main()

